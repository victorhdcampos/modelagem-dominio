
using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using Swashbuckle.AspNetCore.SwaggerGen;
namespace Hospital
  {
  public class ReceitaMedica
  {
      public void GerarReceita(Paciente paciente, List<Medicamento> medicamentos)
      {
          // Cabeçalho da receita
          Console.WriteLine($"Receita médica para o paciente: {paciente.Nome}");
          Console.WriteLine($"Data: {DateTime.Now}");
          Console.WriteLine("-------------------------------------------------");

          // Lista os medicamentos
          foreach (var medicamento in medicamentos)
          {
              Console.WriteLine($"Medicamento: {medicamento.Nome}, Dosagem: {medicamento.Dosagem}, Instruções: {medicamento.Instrucoes}");
          }

          // Rodapé da receita
          Console.WriteLine("-------------------------------------------------");
          Console.WriteLine("Assinatura do médico: ____________________");
          Console.WriteLine("CRM do médico: ____________________");
          Console.WriteLine("-------------------------------------------------");
      }
  }

}
