
using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using Swashbuckle.AspNetCore.SwaggerGen;
namespace Hospital
  {
    public class ReceitaMedicaRefatorada
    {
        public void GerarReceita(Paciente paciente, List<Medicamento> medicamentos)
        {
            GerarCabecalho(paciente);
            ListarMedicamentos(medicamentos);
            GerarRodape();
        }

        private void GerarCabecalho(Paciente paciente)
        {
            Console.WriteLine($"Receita médica para o paciente: {paciente.Nome}");
            Console.WriteLine($"Data: {DateTime.Now}");
            Console.WriteLine("-------------------------------------------------");
        }

        private void ListarMedicamentos(List<Medicamento> medicamentos)
        {
            foreach (var medicamento in medicamentos)
            {
                Console.WriteLine($"Medicamento: {medicamento.Nome}, Dosagem: {medicamento.Dosagem}, Instruções: {medicamento.Instrucoes}");
            }
        }

        private void GerarRodape()
        {
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("Assinatura do médico: ____________________");
            Console.WriteLine("CRM do médico: ____________________");
            Console.WriteLine("-------------------------------------------------");
        }
    }


}
