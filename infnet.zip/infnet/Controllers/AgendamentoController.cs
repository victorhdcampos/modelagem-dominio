using Hospital;
using Microsoft.AspNetCore.Mvc;
using Hospital;

namespace infnet.Controllers;

[ApiController]
[Route("[controller]")]
public class AgendamentoController : ControllerBase
{

    private readonly ILogger<AgendamentoController> _logger;

    public AgendamentoController(ILogger<AgendamentoController> logger)
    {
        _logger = logger;
    }

    [HttpGet(Name = "ObterConsultasPorPaciente")]
    public JsonResult ObterConsultasPorPaciente(Paciente paciente)
    {       
            AgendamentoService agendamentoServico = new AgendamentoService();    
            var agendamentoList = agendamentoServico.ObterConsultasPorPaciente(paciente);
            return new JsonResult(agendamentoList);
    }
}
