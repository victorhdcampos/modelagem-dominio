using Hospital;

namespace SRP;
public class Agendamento
{
    public void MarcarConsulta(Paciente paciente, DateTime data)
    {
        // Lógica para marcar consulta
        Console.WriteLine($"Consulta marcada para o paciente {paciente.Nome} na data {data}");
        // Lógica para persistir no banco de dados
        SalvarNoBanco(paciente, data);
    }

    private void SalvarNoBanco(Paciente paciente, DateTime data)
    {
        // Lógica de persistência
        Console.WriteLine("Consulta salva no banco de dados.");
    }
}