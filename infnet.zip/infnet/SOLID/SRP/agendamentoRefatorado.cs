using Hospital;

namespace SRP;
public class AgendamentoRefatorado
{
    private readonly IRepositorioDeAgendamento _repositorio;

    public AgendamentoRefatorado(IRepositorioDeAgendamento repositorio)
    {
        _repositorio = repositorio;
    }

    public void MarcarConsulta(Paciente paciente, DateTime data)
    {
        // Lógica para marcar consulta
        Console.WriteLine($"Consulta marcada para o paciente {paciente.Nome} na data {data}");

        // Delegar a persistência ao repositório
        _repositorio.SalvarConsulta(paciente, data);
    }
}

public interface IRepositorioDeAgendamento
{
    void SalvarConsulta(Paciente paciente, DateTime data);
}

public class RepositorioDeAgendamento : IRepositorioDeAgendamento
{
    public void SalvarConsulta(Paciente paciente, DateTime data)
    {
        // Lógica de persistência
        Console.WriteLine("Consulta salva no banco de dados.");
    }
}