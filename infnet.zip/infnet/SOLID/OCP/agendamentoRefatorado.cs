using Hospital;

namespace OCP;
public class AgendamentoRefatorado
{
    private readonly IList<INotificacao> _notificacoes;

    public AgendamentoRefatorado(IList<INotificacao> notificacoes)
    {
        _notificacoes = notificacoes;
    }

    public void MarcarConsulta(Paciente paciente, DateTime data)
    {
        // Lógica para marcar consulta
        Console.WriteLine($"Consulta marcada para o paciente {paciente.Nome} na data {data}");

        // Notificar o paciente por diferentes meios
        foreach (var notificacao in _notificacoes)
        {
            notificacao.Enviar(paciente);
        }
    }
}
public interface INotificacao
{
    void Enviar(Paciente paciente);
}
public class NotificacaoPorEmail : INotificacao
{
    public void Enviar(Paciente paciente)
    {
        Console.WriteLine("Notificando paciente por e-mail...");
    }
}
public class NotificacaoPorSms : INotificacao
{
    public void Enviar(Paciente paciente)
    {
        Console.WriteLine("Notificando paciente por SMS...");
    }
}