using Hospital;

namespace OCP;
public class Agendamento
{
    public void MarcarConsulta(Paciente paciente, DateTime data)
    {
        // Lógica para marcar consulta
        Console.WriteLine($"Consulta marcada para o paciente {paciente.Nome} na data {data}");

        // Notificar o paciente (via e-mail)
        Console.WriteLine("Notificando paciente por e-mail...");
    }
}