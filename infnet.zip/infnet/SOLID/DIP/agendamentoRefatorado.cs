using Hospital;

namespace DIP;
public class AgendamentoRefatorado
{
    private readonly IRepositorioDeAgendamento _repositorio;

    public AgendamentoRefatorado(IRepositorioDeAgendamento repositorio)
    {
        _repositorio = repositorio;
    }

    public void MarcarConsulta(Paciente paciente, DateTime data)
    {
        _repositorio.SalvarConsulta(paciente, data);
    }
}
/*
public interface IRepositorioDeAgendamento
{
    void SalvarConsulta(Paciente paciente, DateTime data);
}

public class RepositorioDeAgendamento : IRepositorioDeAgendamento
{
    public void SalvarConsulta(Paciente paciente, DateTime data)
    {
        Console.WriteLine("Consulta salva no banco de dados.");
    }
}*/