using Hospital;

namespace DIP;
public class Agendamento
{
    private readonly RepositorioDeAgendamento _repositorio = new RepositorioDeAgendamento();

    public void MarcarConsulta(Paciente paciente, DateTime data)
    {
        _repositorio.SalvarConsulta(paciente, data);
    }
}