using Hospital;

public abstract class FabricaAgendamento
{
    public abstract Consulta CriarConsulta(Paciente paciente, DateTime data);
}
public class FabricaAgendamentoPresencial : FabricaAgendamento
{
    public override Consulta CriarConsulta(Paciente paciente, DateTime data)
    {
        return new ConsultaPresencial(paciente, data);
    }
}
public class FabricaAgendamentoTeleconsulta : FabricaAgendamento
{
    public override Consulta CriarConsulta(Paciente paciente, DateTime data)
    {
        return new Teleconsulta(paciente, data);
    }
}
public class ConsultaPresencial : Consulta
{
    public ConsultaPresencial(Paciente paciente, DateTime data) : base(paciente, data)
    {   // Lógica específica para consulta presencial
    }
}
public class Teleconsulta : Consulta
{
    public Teleconsulta(Paciente paciente, DateTime data) : base(paciente, data)
    {   // Lógica específica para teleconsulta
    }
}
// Classe base Consulta
public abstract class Consulta
{
    public Paciente Paciente { get; private set; }
    public DateTime Data { get; private set; }
    public Consulta(Paciente paciente, DateTime data)
    {
        Paciente = paciente;
        Data = data;
    }
}