using Hospital;
public class AgendamentoController
{
    private readonly IAgendamentoService _agendamentoService;

    public AgendamentoController(IAgendamentoService agendamentoService)
    {
        _agendamentoService = agendamentoService;
    }

    public void MarcarConsulta(Paciente paciente, DateTime data)
    {
        // Chama o serviço de domínio para realizar o agendamento
        _agendamentoService.MarcarConsulta(paciente, data);
    }

    public List<Consulta> ConsultarAgendamentos(Paciente paciente)
    {
        // Retorna os agendamentos do paciente
        return _agendamentoService.ObterConsultasPorPaciente(paciente);
    }
}