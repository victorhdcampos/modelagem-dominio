namespace Hospital;

public interface IAgendamentoService
{
    void MarcarConsulta(Paciente paciente, DateTime data);
    List<Consulta> ObterConsultasPorPaciente(Paciente paciente);
}