
using Hospital;
public class RepositorioDeAgendamento : IRepositorioDeAgendamento
{
    public void SalvarConsulta(Paciente paciente, DateTime data)
    {
        Console.WriteLine("Consulta salva no banco de dados.");
    }
}