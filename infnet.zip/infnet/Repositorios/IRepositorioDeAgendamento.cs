namespace Hospital;

public interface IRepositorioDeAgendamento
{
    void SalvarConsulta(Paciente paciente, DateTime data);
}