
using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using Swashbuckle.AspNetCore.SwaggerGen;
namespace Hospital
{
    public class Paciente{
        public string Prontuario{get;set;}
        public string Nome{get;set;}
    }

}
