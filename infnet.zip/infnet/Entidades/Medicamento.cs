
using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using Swashbuckle.AspNetCore.SwaggerGen;
namespace Hospital
  {

    public class Medicamento{
        public string Nome{get;set;} 
        public string Dosagem{get;set;} 
        public string Instrucoes{get;set;}
    }     
}
