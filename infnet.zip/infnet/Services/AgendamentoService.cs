using Hospital;

public class AgendamentoService : IAgendamentoService {

    public void MarcarConsulta(Paciente paciente, DateTime data)
    {
        // Lógica de persistência
        Console.WriteLine("Consulta salva no banco de dados.");
    }


    public List<Consulta> ObterConsultasPorPaciente(Paciente paciente){
       
        // Lógica de persistência
        Console.WriteLine("Pesquisar as consultas do paciente no banco de dados.");

        List<Consulta> consultas  = new List<Consulta>();

        ConsultaPresencial consulta  = new ConsultaPresencial(paciente, System.DateTime.Now);

        consultas.Add(consulta);

        return consultas;
    }

}